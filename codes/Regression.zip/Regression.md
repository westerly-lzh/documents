


回归分析
========================================================
date: 2014-06-01
author: 李争，姚锐，谢少勇，高跃，李亚惠，芶小婷，袁琳
width: 1440
height: 900
autosize: true
transition: rotate

$$\bf{y} = f(\bf{X})+\bf{\varepsilon}$$

内容
========================================================


- 基本概念及技巧
- 一元线性回归
- 多元线性回归
- 多重共线性
- 线性回归中杂项
- Logistic回归
- 案例

基本概念及技巧1--基本概念
========================================================
transition: zoom
$$\forall -\infty \lt \alpha \lt \infty , \exists \quad F_X(\alpha) = \int_{-\infty}^{\alpha} f_X(x)dx$$

- $F_x(\alpha)$,累计概率分布函数
- $f_x(\alpha)$,概率密度函数

$$\begin{aligned}Cov(X,Y) & = E\lbrace\lbrack X-E(X)\rbrack\lbrack Y - E(Y)\rbrack\rbrace \\
\rho(X,Y) & = \frac{Cov(X,Y)}{\sigma(X)\sigma(Y)}\end{aligned}$$

- $Cov(X,Y)$,协方差
- $\rho(X,Y)$,相关系数
- $\sigma(X)$,标准差

基本概念及技巧2--假设
========================================================
transition: zoom
- **研究假设，备择假设($H_1$)**:在研究过程中希望得到支持的假设。
- **零假设($H_0$)**:与研究假设对立的假设
- $\bf{\alpha}$类错误
- $\bf{\beta}$类错误
- 单尾检验
- 双尾检验

基本概念及技巧3--标准化
========================================================
transition: zoom
$$z = \frac{X - E(X)}{\sigma(X)}$$

该变量的标准化，得到一个均值为0，方差为1的**无量纲**的纯数。使得在做多元回归时，得到的**回归系数可以进行比较**。标准化可以有效解决由于变量的测量单位不同而导致的结果不可比的问题。

基本概念及技巧4-数据变换
========================================================
transition: zoom
+ 对数变换
+ 二次项变换



一元线性回归-模型
========================================================
transition: concave
$$
\begin{aligned}
y_i & = \beta_0 + \beta_1 x_i + \varepsilon_i
\end{aligned}$$



有观测值$(y_1,x_1),(y_2,x_2),...,(y_n,x_n),$,假设得到**经验回归方程**：
$$
\begin{aligned}
\hat{y_i} & = b_0 +b_1 x_i
\end{aligned}$$
一元线性回归-最小二乘估计
========================================================
transition: concave
若要经验回归方程可以最准确的表示实际的数据关系，则需要使得观测值$y_i$与拟合值$\hat{y_i}$的差距最小[^1]：
$$
\begin{aligned}
min D &= min\sum_i^n(y_i - \hat{y_i})^2 \\
& = min\sum_i^n(y_i - b_0 - b_1 x_i)^2
\end{aligned}$$
可以求得当：
$$
\begin{aligned}
b_1 & = \frac{\sum(x_i-\bar{x})(y_i - \bar{y})}{\sum(x_i - \bar{x})^2} = \frac{Cov(x,y)}{Var(x)}\\
b_0 & = \bar{y} - b_1 \bar{x}
\end{aligned}
$$
$$$$



[^1]:实际上使用最小距离偏差法(LAD)结果更优，$min D = min \sum{|y_i - \hat{y_i}|}$
一元线性回归-回归模型的基本假设
========================================================
transition: concave
$$y_i = \beta_0 + \beta_1 x_i + \varepsilon_i$$
+ **正交假设**: $Cov(X,\varepsilon)=0,E(\varepsilon)=0,Cov(\hat{Y},\varepsilon)$
+ **独立同分布**:$Cov(\varepsilon_i,\varepsilon_j)=0,\sigma_{\varepsilon}^2=\sigma^2$
+ **正态性**：在小样本情况下$\varepsilon_i \sim N(0,\sigma^2)$；在大样本情况下，由中心极限定理，可以对$\varepsilon$不做正态性假设。
一元线性回归-拟合效果
========================================================
transition: concave
$$
\begin{aligned}
SST & = \sum_i^n(y_i - \bar{y})^2  = \sum_i^n(y_i - \hat{y_i})^2 + \sum_i^n(\hat{y_i} - \bar{y})^2 \\
    & = SSE + SSR \\
    总变异 & = 未被解释的变异+被解释的变异
\end{aligned}
$$
- **总离差(SST)**： $SST = \sum_i^n(y_i - \bar{y})^2$
- **残差平方和(SSE)** $\sum_i^n(y_i - \hat{y_i})^2$
- **回归平方和(SSR)**: $\sum_i^n(\hat{y_i} - \bar{y})^2$
一元线性回归-拟合效果2
========================================================
transition: concave
定义被解释的变异占总变异的比例为：
$$R^2 = \frac{SSR}{SST} = \frac{\sum_i^n(\hat{y_i} - \bar{y})^2}{\sum_i^n(y_i - \bar{y})^2} = \frac{SST - SSE}{SST}$$
- $R^2 \in [0,1]$

把 $b_1 = \frac{\sum(x_i-\bar{x})(y_i - \bar{y})}{\sum(x_i - \bar{x})^2},b_0 = \bar{y}-b_1\bar{x},\hat{y} = b_0 + b_1 x_1$代入上式，可以得到
$$R^2 = [\frac{Cov(x,y)}{\sqrt{Var(x)}\sqrt{Var(y)}}]^2$$对比前面相关系数的定义，可以知道$R^2$是样本相关系数的平方，且可以在不知道拟合值的情况下用来计算$R^2$

一元线性回归-检验
========================================================
transition: concave
+ 模型整体性检验 
  + 模型的效果是由$R^2$来测量的
  + 对模型的检验则需要对$R^2$进行检验，但$R^2$不能直接检验
  + 构造和$R^2$相关的量进行检验---F统计量
+ 回归系数检验($H_0:\beta_1=0;H_1:\beta_1\ne 0$)
  + $SSE = \sum(y-\bar{y})^2,MSE = \frac{SSE}{n-2}$
  + 构造统计量:$t(f) = \frac{\hat{\beta_1} - \beta_1}{\sqrt{{MSE}/{\sum(x-\bar{x})^2}}}$



多元线性回归-模型
========================================================
transition: linear
$$
\bf{y} = \bf{X\beta}+\bf{\varepsilon}
$$
+ $E(\bf{\varepsilon}) = \bf{0}$
+ $Cov(\bf{X},\bf{\varepsilon}) = 0$
+ \(Var(\varepsilon_i,\varepsilon_j) = \begin{cases} \sigma^2, i=j \\ 0, i \neq j \end{cases}\)
+ 小样本时，\(\bf{\varepsilon} \sim N(0,\sigma^2I)  \)
多元线性回归-回归系数
========================================================
transition: linear
$$
\begin{aligned}
Q(\bf{\beta} ) &= (\bf{Y} - \bf{X\beta})^T(\bf{Y} - \bf{X\beta})\\
Min Q(\bf{\beta}) &= Min (\bf{Y} - \bf{X\beta})^T(\bf{Y} - \bf{X\beta})
\end{aligned}
$$

<hr />
$$
\begin{aligned}
\frac{\partial{Q(\bf{\beta})}}{\partial{\bf{\beta}}}  &=  - X^TY - Y^TX + 2X^TX\beta =0\\
\hat{\beta} &= (X^TX)^{-1}X^TY = HY
\end{aligned}
$$
+ \( H =(X^TX)^{-1}X^T \),对称幂等阵

多元线性回归-检验
========================================================
transition: linear
+ 全模型检验
  + \(F = \frac{SSR/(p -1)}{SSE/(n-p)}\),p为模型中\(\beta\)的个数,包含截距项
+ 单独的\(\beta_i = 0\)的检验
  + \(Z = \frac{\bar{X} - \mu}{\sigma/\sqrt{n}} \sim N(0,1)\)，知道总体均值和方差
  + \(t = \frac{\bar{X} - \mu}{S\sqrt{n-1}} \sim t(n-1)\)，知道总体均值


多重共线性
===========================================
transition: fade
$$
\hat{\beta}  = (X^TX)^{-1}X^TY
$$
+ 若\(X^TX\)不可逆或者近似不可逆
多重共线性问题：
 + $$x_k = \alpha_0+\alpha_1x_1+...+\alpha_{k-1}x_{k-1} + \alpha_{k+1}x_{k+1}+... \alpha_px_p + \varepsilon$$
  + 若\(R_{x_k}^2 = \frac{SSR_{x_k}}{SST_{x_k}} \)较大，则说明\(x_k\)可以由其他变量很好地解释，若\(R_{x_k}^2 =1\)则完全共线性，\(R_{x_k}^2 \)接近1，则近似共线性

<hr />

+ 解决方式
  + 主成分:把具有共线性的变量使用较少的新变量来代替，新变量具有正交关系
  + 岭回归:修改\((X^TX)^{-1}X^TY\)为\((X^TX+kI)^{-1}X^TY\),需要确定参数k
  + 逐步回归:(主要解决因为多引入变量，导致的共线性问题),逐步引入和删除一些项，选取一部分对回归贡献最大的项进入回归方程，使得残差尽可能小
  
线性回归中杂项
========================================================
transition: fade
“线性回归”中的“线性”实际是指的回归方程中系数是线性的。所以下面的一些例子也是属于线性回归的范畴：
+ 带有交互项的多项式回归
  + \( y_i = \beta_0 + \beta_1x_1+\beta_2x_1^2 + \beta_3x_2+ \beta_4x_2^2+\beta_5x_1x_2+\varepsilon\)
  + 使用正交方式，解决多重共线性问题
+ 分类变量处理。有分类变量（高,中,低），映射为（L1,L2,L3）这三个虚拟变量
  + <table>
  <tr>
  <td>ID</td><td>水平</td><td>L1</td><td>L2</td><td>L3</td>
  </tr>
  <tr><td>1</td><td>高</td>
  <td>1</td><td>0</td><td>0</td>
  </tr>
  <tr><td>2</td><td>中</td><td>0</td><td>1</td><td>0</td>
  </tr>
  <tr><td>2</td><td>低</td><td>0</td><td>0</td><td>1</td>
  </tr>
  </table>
  

Logistic回归1
========================================================
transition: zoom
+ 一般线性回归
  + \(y = f(X)+\varepsilon, y \in (-\infty,+\infty)\) 
+ 当y为分类变量,不妨设\( y \in \{1,2,3,..,k\}\)
  + \( P(y=i|X)=p_i\)
  + \(p_i \in (0,1)\),这里不妨设事件\(y=i\)是可能发生的
  + \( p_i = X\beta_i + \varepsilon_i\)
  + 但 \(p_i\)变化范围太集中，模型不稳定。
  + \(p_i = P(y=i|X) = \frac{e^{X\beta_i}}{\sum_{j=1}^{k}{e^{X\beta_j}}}\)
  + \(p_k = P(y=k|X) = \frac{e^{X\beta_k}}{\sum_{j=1}^{k}{e^{X\beta_j}}}\)

  
Logistic回归2
========================================================
transition: zoom
+ \(\frac{p_i}{p_k} = e^{X(\beta_i - \beta_k)}\)
+ 令 \(\hat{\beta_i} = \beta_i - \beta_k \)
+ \(p_i = p_k e^{\hat{\beta_i}}\)
+ 由 \(\sum p_i = 1 \) => \( p_k = \frac{1}{1+ \sum_{j=1}^{k-1} e^{X\hat{\beta_j}}}\)
+ \(p_i = \frac{e^{X\beta_i}}{\sum_{j=1}^{k}{e^{X\beta_j}}} = \frac{e^{X\beta_i}/{e^{X\beta_k}}}{\sum_{j=1}^{k}{e^{X\beta_j}}/{e^{X\beta_k}}} = \frac{e^{X(\beta_i - \beta_k)}}{\sum_{j=1}^{k-1}e^{X(\beta_j - \beta_k)} + e^0} = \frac{e^{X\hat{\beta_i}}}{1+ \sum_{j=1}^{k-1} e^{X\hat{\beta_j}}}\) 
+ \(\frac{p_i}{p_k} = e^{X\hat{\beta_i}}\)
+ 令 \( \beta_i =\hat{\beta_i}, logist(p_i) = ln(\frac{p_i}{p_k}) = X\beta_i + \varepsilon_i\)
+ 当k=2时，退化成0-1型Logistc回归
  
案例1-数据说明
========================================================
transition: zoom
来自Ledolter and Tiao(1979)和 Hogg and Ledolter(1992)的数据是洛杉矶一个站点从午夜开始的24小事中所测量的一氧化碳（变量CO）在整个夏天（周末除外）的均值，另外还有3个关于事件，地点，风速的变量，该数据是一个24*4的矩阵。变量说明如下表:
 <table>
  <tr>
  <td>变量名</td><td>描述</td><td>性质</td>
  </tr>
  <tr><td>CO</td><td>一氧化碳均值</td><td>定量变量</td>
  </tr>
  <tr><td>Hour</td><td>时间点</td><td>定量变量</td>
  </tr>
  <tr><td>Traffic</td><td>交通密度（交通车辆数除以交通速度）</td><td>定量变量</td>
  </tr>
  <tr><td>Wind</td><td>风速的竖直分量</td><td>定量变量</td>
  </tr>
  </table>
案例1-数据
========================================================
transition: zoom


```r
w <- read.table("cofreewy.txt",header=T)
head(w,24)
```

```
   Hour  CO Traffic Wind
1     1 2.4      50 -0.2
2     2 1.7      26  0.0
3     3 1.4      16  0.0
4     4 1.2      10  0.0
5     5 1.2      12  0.1
6     6 2.0      41 -0.1
7     7 3.4     157 -0.1
8     8 5.8     276 -0.2
9     9 6.8     282  0.2
10   10 6.6     242  1.0
11   11 6.6     200  2.3
12   12 6.3     186  3.8
13   13 5.8     179  4.6
14   14 5.5     178  5.4
15   15 5.9     203  5.9
16   16 6.8     264  5.9
17   17 7.0     289  5.6
18   18 7.4     308  4.9
19   19 6.4     267  3.8
20   20 5.0     190  2.5
21   21 3.8     125  1.4
22   22 3.5     120  0.6
23   23 3.3     116  0.4
24   24 3.1      87  0.1
```
案例1 - 描述性分析
========================================================
transition: zoom

```r
summary(w)
```

```
      Hour             CO           Traffic            Wind       
 Min.   : 1.00   Min.   :1.200   Min.   : 10.00   Min.   :-0.200  
 1st Qu.: 6.75   1st Qu.:2.925   1st Qu.: 77.75   1st Qu.: 0.000  
 Median :12.50   Median :5.250   Median :178.50   Median : 0.800  
 Mean   :12.50   Mean   :4.537   Mean   :159.33   Mean   : 1.996  
 3rd Qu.:18.25   3rd Qu.:6.450   3rd Qu.:247.50   3rd Qu.: 4.000  
 Max.   :24.00   Max.   :7.400   Max.   :308.00   Max.   : 5.900  
```


案例1 - 全部数据回归
========================================================
transition: linear

```r
a <- lm(CO~.,w)
summary(a)
```

```

Call:
lm(formula = CO ~ ., data = w)

Residuals:
     Min       1Q   Median       3Q      Max 
-0.75030 -0.33275 -0.09021  0.22653  1.25112 

Coefficients:
             Estimate Std. Error t value Pr(>|t|)    
(Intercept)  1.318967   0.242522   5.439 2.53e-05 ***
Hour        -0.005689   0.017066  -0.333  0.74233    
Traffic      0.018402   0.001413  13.026 3.15e-11 ***
Wind         0.179189   0.059517   3.011  0.00691 ** 
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

Residual standard error: 0.5096 on 20 degrees of freedom
Multiple R-squared:  0.9498,	Adjusted R-squared:  0.9423 
F-statistic: 126.1 on 3 and 20 DF,  p-value: 3.682e-13
```
案例1 - 验证
========================================================
transition: linear

```r
plot(w[,"CO"],type="l",ylim=c(-0.5,8))
points(c(as.matrix(w)[,c("Hour","Traffic","Wind")]%*%(a$coefficients[2:4]))+a$coefficients[1])
```

<img src="Regression-figure/unnamed-chunk-4-1.png" title="plot of chunk unnamed-chunk-4" alt="plot of chunk unnamed-chunk-4" width="1200" height="1200" style="display: block; margin: auto;" />
案例1 - 逐步回归
========================================================
transition: linear
逐步回归中，使用AIC准则，小于AIC信息值的舍去。

```r
b <- step(a,direction="backward")
```

```
Start:  AIC=-28.73
CO ~ Hour + Traffic + Wind

          Df Sum of Sq    RSS     AIC
- Hour     1     0.029  5.224 -30.597
<none>                  5.195 -28.730
- Wind     1     2.354  7.549 -21.759
- Traffic  1    44.070 49.265  23.260

Step:  AIC=-30.6
CO ~ Traffic + Wind

          Df Sum of Sq    RSS     AIC
<none>                  5.224 -30.597
- Wind     1     2.357  7.581 -23.659
- Traffic  1    46.117 51.341  22.250
```
案例1 - 全部数据回归
========================================================
transition: linear

```r
summary(b)
```

```

Call:
lm(formula = CO ~ Traffic + Wind, data = w)

Residuals:
     Min       1Q   Median       3Q      Max 
-0.72858 -0.31710 -0.09629  0.22409  1.26554 

Coefficients:
            Estimate Std. Error t value Pr(>|t|)    
(Intercept) 1.274461   0.198137   6.432 2.25e-06 ***
Traffic     0.018290   0.001343  13.616 6.85e-12 ***
Wind        0.174747   0.056765   3.078   0.0057 ** 
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

Residual standard error: 0.4987 on 21 degrees of freedom
Multiple R-squared:  0.9495,	Adjusted R-squared:  0.9447 
F-statistic: 197.5 on 2 and 21 DF,  p-value: 2.419e-14
```
案例1 - 验证1
========================================================
transition: linear

```r
shapiro.test(b$res)
```

```

	Shapiro-Wilk normality test

data:  b$res
W = 0.9192, p-value = 0.05601
```

案例1 - 验证2
========================================================
transition: linear

```r
qqnorm(b$res)
qqline(b$res)
```

<img src="Regression-figure/unnamed-chunk-8-1.png" title="plot of chunk unnamed-chunk-8" alt="plot of chunk unnamed-chunk-8" width="1200" height="1200" style="display: block; margin: auto;" />
案例1 - 验证3
========================================================
transition: linear

```r
a <- lm(CO ~ Traffic + Wind,w)
plot(w[,"CO"],type="l",ylim=c(-0.5,8))
points(c(as.matrix(w)[,c("Traffic","Wind")]%*%(a$coefficients[2:3]))+a$coefficients[1])
```

<img src="Regression-figure/unnamed-chunk-9-1.png" title="plot of chunk unnamed-chunk-9" alt="plot of chunk unnamed-chunk-9" width="1200" height="1200" style="display: block; margin: auto;" />
案例1 -  再次探索数据
========================================================
transition: linear

```r
plot(w)
```

<img src="Regression-figure/unnamed-chunk-10-1.png" title="plot of chunk unnamed-chunk-10" alt="plot of chunk unnamed-chunk-10" width="1200" height="1200" style="display: block; margin: auto;" />

案例1 -  探索结论
========================================================
transition: linear

+ CO与Traffic有线性关系
  + \(CO\sim \beta_1 Traffic+\beta_2 Traffic^2 +\beta_3 Traffic^3\)
  + \(CO\sim \beta_1 Traffic\)
+ CO与Wind有较为复杂的关系
  + \(CO\sim \beta_1 Wind + \beta_2 Wind^2 + \beta_3 Wind^3\)
+ CO与Hour有类似叠加的正弦关系
  + \(CO \sim sin(\frac{2\pi}{24}Hour) + \sin(\frac{4\pi}{24}Hour)+cos(\frac{2\pi}{24}Hour) + \cos(\frac{4\pi}{24}Hour) \)
案例1 -  探索结论1
========================================================
transition: linear

```r
c <- lm(CO~Traffic+I(Traffic^2)+I(Traffic^3)+ 
          Wind+I(Wind^2)+I(Wind^3)+
          sin((2*pi/24)*Hour)+sin((4*pi/24)*Hour)+
          cos((2*pi/24)*Hour)+cos((4*pi/24)*Hour),w)
summary(c)
```

```

Call:
lm(formula = CO ~ Traffic + I(Traffic^2) + I(Traffic^3) + Wind + 
    I(Wind^2) + I(Wind^3) + sin((2 * pi/24) * Hour) + sin((4 * 
    pi/24) * Hour) + cos((2 * pi/24) * Hour) + cos((4 * pi/24) * 
    Hour), data = w)

Residuals:
     Min       1Q   Median       3Q      Max 
-0.20196 -0.10202 -0.04372  0.11283  0.27964 

Coefficients:
                          Estimate Std. Error t value Pr(>|t|)  
(Intercept)              1.658e+00  8.083e-01   2.052   0.0609 .
Traffic                  2.447e-02  1.250e-02   1.958   0.0720 .
I(Traffic^2)            -9.207e-05  7.820e-05  -1.177   0.2602  
I(Traffic^3)             2.357e-07  1.515e-07   1.556   0.1438  
Wind                     8.584e-01  4.730e-01   1.815   0.0927 .
I(Wind^2)               -2.698e-01  1.361e-01  -1.983   0.0690 .
I(Wind^3)                2.092e-02  1.278e-02   1.637   0.1256  
sin((2 * pi/24) * Hour) -3.180e-01  9.166e-01  -0.347   0.7342  
sin((4 * pi/24) * Hour)  2.303e-01  5.596e-01   0.411   0.6874  
cos((2 * pi/24) * Hour) -7.665e-01  6.637e-01  -1.155   0.2689  
cos((4 * pi/24) * Hour)  3.801e-01  1.797e-01   2.115   0.0543 .
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

Residual standard error: 0.1873 on 13 degrees of freedom
Multiple R-squared:  0.9956,	Adjusted R-squared:  0.9922 
F-statistic: 293.7 on 10 and 13 DF,  p-value: 1.269e-13
```
案例1 -  探索结论2
========================================================

```r
d <- step(c)
```

```
Start:  AIC=-73.12
CO ~ Traffic + I(Traffic^2) + I(Traffic^3) + Wind + I(Wind^2) + 
    I(Wind^3) + sin((2 * pi/24) * Hour) + sin((4 * pi/24) * Hour) + 
    cos((2 * pi/24) * Hour) + cos((4 * pi/24) * Hour)

                          Df Sum of Sq     RSS     AIC
- sin((2 * pi/24) * Hour)  1  0.004221 0.46018 -74.901
- sin((4 * pi/24) * Hour)  1  0.005939 0.46189 -74.811
<none>                                 0.45595 -73.122
- cos((2 * pi/24) * Hour)  1  0.046791 0.50275 -72.777
- I(Traffic^2)             1  0.048613 0.50457 -72.691
- I(Traffic^3)             1  0.084893 0.54085 -71.024
- I(Wind^3)                1  0.093967 0.54992 -70.625
- Wind                     1  0.115512 0.57147 -69.703
- Traffic                  1  0.134480 0.59043 -68.919
- I(Wind^2)                1  0.137849 0.59380 -68.782
- cos((4 * pi/24) * Hour)  1  0.156933 0.61289 -68.023

Step:  AIC=-74.9
CO ~ Traffic + I(Traffic^2) + I(Traffic^3) + Wind + I(Wind^2) + 
    I(Wind^3) + sin((4 * pi/24) * Hour) + cos((2 * pi/24) * Hour) + 
    cos((4 * pi/24) * Hour)

                          Df Sum of Sq     RSS     AIC
- sin((4 * pi/24) * Hour)  1   0.00179 0.46197 -76.808
<none>                                 0.46018 -74.901
- I(Traffic^2)             1   0.04439 0.50457 -74.691
- I(Traffic^3)             1   0.08119 0.54136 -73.001
- I(Wind^3)                1   0.11018 0.57036 -71.749
- Traffic                  1   0.13116 0.59133 -70.882
- I(Wind^2)                1   0.14395 0.60413 -70.368
- Wind                     1   0.35074 0.81091 -63.304
- cos((4 * pi/24) * Hour)  1   0.48722 0.94739 -59.570
- cos((2 * pi/24) * Hour)  1   0.98829 1.44846 -49.381

Step:  AIC=-76.81
CO ~ Traffic + I(Traffic^2) + I(Traffic^3) + Wind + I(Wind^2) + 
    I(Wind^3) + cos((2 * pi/24) * Hour) + cos((4 * pi/24) * Hour)

                          Df Sum of Sq     RSS     AIC
<none>                                 0.46197 -76.808
- I(Traffic^2)             1   0.07723 0.53920 -75.098
- I(Traffic^3)             1   0.12546 0.58743 -73.041
- I(Wind^3)                1   0.16668 0.62864 -71.414
- I(Wind^2)                1   0.32070 0.78267 -66.154
- Traffic                  1   0.49989 0.96185 -61.207
- Wind                     1   0.82038 1.28234 -54.305
- cos((2 * pi/24) * Hour)  1   0.99836 1.46032 -51.186
- cos((4 * pi/24) * Hour)  1   1.48098 1.94294 -44.332
```
案例1 -  探索结论3
========================================================

```r
summary(d)
```

```

Call:
lm(formula = CO ~ Traffic + I(Traffic^2) + I(Traffic^3) + Wind + 
    I(Wind^2) + I(Wind^3) + cos((2 * pi/24) * Hour) + cos((4 * 
    pi/24) * Hour), data = w)

Residuals:
     Min       1Q   Median       3Q      Max 
-0.21657 -0.09544 -0.04405  0.12139  0.29837 

Coefficients:
                          Estimate Std. Error t value Pr(>|t|)    
(Intercept)              1.532e+00  1.297e-01  11.808 5.39e-09 ***
Traffic                  2.094e-02  5.197e-03   4.029 0.001093 ** 
I(Traffic^2)            -7.101e-05  4.484e-05  -1.584 0.134147    
I(Traffic^3)             1.974e-07  9.782e-08   2.018 0.061806 .  
Wind                     9.269e-01  1.796e-01   5.161 0.000116 ***
I(Wind^2)               -2.501e-01  7.752e-02  -3.227 0.005644 ** 
I(Wind^3)                2.012e-02  8.647e-03   2.326 0.034422 *  
cos((2 * pi/24) * Hour) -5.356e-01  9.406e-02  -5.694 4.26e-05 ***
cos((4 * pi/24) * Hour)  4.488e-01  6.472e-02   6.934 4.78e-06 ***
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

Residual standard error: 0.1755 on 15 degrees of freedom
Multiple R-squared:  0.9955,	Adjusted R-squared:  0.9932 
F-statistic:   418 on 8 and 15 DF,  p-value: 3.303e-16
```
案例1 -  探索结论4
========================================================

```r
e <- lm(CO~Traffic+
          Wind+I(Wind^2)+I(Wind^3)+
          cos((2*pi/24)*Hour)+cos((4*pi/24)*Hour),w)
summary(e)
```

```

Call:
lm(formula = CO ~ Traffic + Wind + I(Wind^2) + I(Wind^3) + cos((2 * 
    pi/24) * Hour) + cos((4 * pi/24) * Hour), data = w)

Residuals:
     Min       1Q   Median       3Q      Max 
-0.40661 -0.11179 -0.00845  0.11289  0.33396 

Coefficients:
                         Estimate Std. Error t value Pr(>|t|)    
(Intercept)              1.398721   0.110478  12.661 4.41e-10 ***
Traffic                  0.017179   0.000722  23.795 1.72e-14 ***
Wind                     0.580844   0.193422   3.003 0.008003 ** 
I(Wind^2)               -0.119450   0.087414  -1.366 0.189590    
I(Wind^3)                0.007288   0.010072   0.724 0.479116    
cos((2 * pi/24) * Hour) -0.375632   0.087473  -4.294 0.000491 ***
cos((4 * pi/24) * Hour)  0.377728   0.071670   5.270 6.25e-05 ***
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

Residual standard error: 0.2261 on 17 degrees of freedom
Multiple R-squared:  0.9916,	Adjusted R-squared:  0.9886 
F-statistic: 334.5 on 6 and 17 DF,  p-value: < 2.2e-16
```

案例1 -  探索结论5
========================================================

```r
anova(e)
```

```
Analysis of Variance Table

Response: CO
                        Df Sum Sq Mean Sq   F value    Pr(>F)    
Traffic                  1 95.875  95.875 1875.5497 < 2.2e-16 ***
Wind                     1  2.357   2.357   46.1126 3.149e-06 ***
I(Wind^2)                1  1.409   1.409   27.5619 6.518e-05 ***
I(Wind^3)                1  0.052   0.052    1.0087    0.3293    
cos((2 * pi/24) * Hour)  1  1.474   1.474   28.8376 5.090e-05 ***
cos((4 * pi/24) * Hour)  1  1.420   1.420   27.7770 6.248e-05 ***
Residuals               17  0.869   0.051                        
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
```

```r
shapiro.test(e$res)
```

```

	Shapiro-Wilk normality test

data:  e$res
W = 0.9782, p-value = 0.8596
```
案例1 -  探索结论6
========================================================

```r
qqnorm(e$res)
qqline(e$res)
```

<img src="Regression-figure/unnamed-chunk-16-1.png" title="plot of chunk unnamed-chunk-16" alt="plot of chunk unnamed-chunk-16" width="1200" height="1200" style="display: block; margin: auto;" />
案例1 -  探索结论7
========================================================

```r
nd <- cbind(Traffic=w[,"Traffic"],Wind = w[,"Wind"],Wind2 = w[,"Wind"]^2,Wind3 <- w[,"Wind"]^3,Hour2 = cos((2*pi/24)*w[,"Hour"]),Hour4=cos((4*pi/24)*w[,"Hour"]))
m <- c(nd%*%(e$coefficients[2:7]))
plot(w[,"CO"],type="l")
points(m+e$coefficients[1])
```

<img src="Regression-figure/unnamed-chunk-17-1.png" title="plot of chunk unnamed-chunk-17" alt="plot of chunk unnamed-chunk-17" width="1200" height="1200" style="display: block; margin: auto;" />
案例1 -  探索结论8
========================================================

```r
f <- lm(CO~Traffic+
          Wind+I(Wind^2)+
          cos((2*pi/24)*Hour)+cos((4*pi/24)*Hour),w)
summary(f)
```

```

Call:
lm(formula = CO ~ Traffic + Wind + I(Wind^2) + cos((2 * pi/24) * 
    Hour) + cos((4 * pi/24) * Hour), data = w)

Residuals:
     Min       1Q   Median       3Q      Max 
-0.41964 -0.09082 -0.00460  0.13950  0.32727 

Coefficients:
                          Estimate Std. Error t value Pr(>|t|)    
(Intercept)              1.3983633  0.1090058  12.828 1.71e-10 ***
Traffic                  0.0172434  0.0007069  24.394 3.05e-15 ***
Wind                     0.4587252  0.0932634   4.919 0.000111 ***
I(Wind^2)               -0.0573112  0.0161534  -3.548 0.002298 ** 
cos((2 * pi/24) * Hour) -0.3668116  0.0854664  -4.292 0.000439 ***
cos((4 * pi/24) * Hour)  0.3861623  0.0697739   5.534 2.96e-05 ***
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

Residual standard error: 0.2231 on 18 degrees of freedom
Multiple R-squared:  0.9913,	Adjusted R-squared:  0.9889 
F-statistic: 412.2 on 5 and 18 DF,  p-value: < 2.2e-16
```

案例1 -  探索结论9
========================================================

```r
anova(f)
```

```
Analysis of Variance Table

Response: CO
                        Df Sum Sq Mean Sq  F value    Pr(>F)    
Traffic                  1 95.875  95.875 1926.530 < 2.2e-16 ***
Wind                     1  2.357   2.357   47.366 1.948e-06 ***
I(Wind^2)                1  1.409   1.409   28.311 4.661e-05 ***
cos((2 * pi/24) * Hour)  1  1.395   1.395   28.021 4.941e-05 ***
cos((4 * pi/24) * Hour)  1  1.524   1.524   30.630 2.964e-05 ***
Residuals               18  0.896   0.050                       
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
```

```r
shapiro.test(e$res)
```

```

	Shapiro-Wilk normality test

data:  e$res
W = 0.9782, p-value = 0.8596
```
案例1 -  探索结论10
========================================================

```r
qqnorm(f$res)
qqline(f$res)
```

<img src="Regression-figure/unnamed-chunk-20-1.png" title="plot of chunk unnamed-chunk-20" alt="plot of chunk unnamed-chunk-20" width="1200" height="1200" style="display: block; margin: auto;" />
案例1 -  探索结论9
========================================================

```r
nd <- cbind(Traffic=w[,"Traffic"],Wind = w[,"Wind"],Wind2 = w[,"Wind"]^2,Hour2 = cos((2*pi/24)*w[,"Hour"]),Hour4=cos((4*pi/24)*w[,"Hour"]))
m <- c(nd%*%(f$coefficients[2:6]))
plot(w[,"CO"],type="l")
points(m+f$coefficients[1])
```

<img src="Regression-figure/unnamed-chunk-21-1.png" title="plot of chunk unnamed-chunk-21" alt="plot of chunk unnamed-chunk-21" width="1200" height="1200" style="display: block; margin: auto;" />
案例2 -  Logistic回归1
========================================================
旅行模式数据(TravelMode.csv)是关于在澳大利亚悉尼和墨尔本之间旅行模式的选择，因变量mode有4个旅行模式，210个对象，每个对象有4次观测
 <table width="1200px">
  <tr>
  <td>变量名</td><td>描述</td><td>性质</td><td>变量名</td><td>描述</td><td>性质</td>
  </tr>
  <tr>
  <td>individual</td><td>个体代码</td><td>分类变量</td><td>mode</td><td>旅行模式</td><td>分类变量</td>
  </tr>
  <tr>
  <td>choice</td><td>选择（no，yes）</td><td>分类变量</td><td>wait</td><td>等待时间</td><td>定量变量</td>
  </tr>
  <tr>
  <td>vcost</td><td>车辆话费</td><td>定量变量</td><td>travel</td><td>车内耗时</td><td>定量变量</td>
  </tr>
  <tr>
  <td>gcost</td><td>总花费</td><td>定量变量</td><td>income</td><td>家庭收入</td><td>定量变量</td>
  </tr>
  <tr>
  <td>size</td><td>旅行人数</td><td>整数</td> <td>incair</td><td>NA</td><td>整数</td>
  </tr>
  </table>

```r
data(TravelMode,package="AER")
head(TravelMode,6)
```

```
  individual  mode choice wait vcost travel gcost income size
1          1   air     no   69    59    100    70     35    1
2          1 train     no   34    31    372    71     35    1
3          1   bus     no   35    25    417    70     35    1
4          1   car    yes    0    10    180    30     35    1
5          2   air     no   64    58     68    68     30    2
6          2 train     no   44    31    354    84     30    2
```
$$
P(Y=i)=\frac{e^{\beta_{i0}+\beta_{i1}gcost+\beta_{i2}wait+\beta_{i3}income}}{1+ \sum_{j=2}^4 e^{\beta_{j0}+\beta_{j1}gcost+\beta_{j2}wait+\beta_{j3}income}},i=2,3,4
$$
案例2 -  Logistic回归2
========================================================

```r
require(mlogit)
g <- mlogit(choice~gcost+wait|income,
            data=TravelMode,shape="long",
            alt.var="mode",reflevel="car")#reflevel指定参照类别
summary(g)
```

```

Call:
mlogit(formula = choice ~ gcost + wait | income, data = TravelMode, 
    reflevel = "car", shape = "long", alt.var = "mode", method = "nr", 
    print.level = 0)

Frequencies of alternatives:
    car     air   train     bus 
0.28095 0.27619 0.30000 0.14286 

nr method
5 iterations, 0h:0m:0s 
g'(-H)^-1g = 0.000614 
successive function values within tolerance limits 

Coefficients :
                    Estimate Std. Error t-value  Pr(>|t|)    
air:(intercept)    5.8747921  0.8020903  7.3244 2.400e-13 ***
train:(intercept)  5.5498345  0.6404244  8.6659 < 2.2e-16 ***
bus:(intercept)    4.1302566  0.6763628  6.1066 1.018e-09 ***
gcost             -0.0109273  0.0045878 -2.3818   0.01723 *  
wait              -0.0954602  0.0104732 -9.1147 < 2.2e-16 ***
air:income        -0.0053735  0.0115294 -0.4661   0.64116    
train:income      -0.0565616  0.0139733 -4.0478 5.170e-05 ***
bus:income        -0.0285836  0.0154442 -1.8508   0.06420 .  
---
Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1

Log-Likelihood: -189.53
McFadden R^2:  0.33209 
Likelihood ratio test : chisq = 188.47 (p.value = < 2.22e-16)
```
Thanks
========================================================
Reference：

1. 谢宇，《回归分析》，社会科学文献出版社，2010-8，第一版
2. 何晓群 刘文卿 《应用回归分析》，中国人民大学出版社，2011-9，第一版
3. Samprit Chatterjee Ali S.Hadi 《例解回归分析》，机械工业出版社，2013-8，第五版
4. 梅长林 王宁 《近代回归分析》，科学出版社，2012-1，第一版
5. Rudolf J.Freud William J.Wilson Ping Sa 《回归分析 因变量统计模型》，重庆大学出版社，2012-9，第一版
6. 吴喜之 《复杂数据统计方法--基于R的应用》，中国人民大学出版社，2012-10，第一版

